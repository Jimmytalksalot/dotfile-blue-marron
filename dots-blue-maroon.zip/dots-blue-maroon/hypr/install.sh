# DEBIAN ONLY.

read -p "This program will install the needed apps, if not already installed. Contine? CRTL + C to exit." input
sudo apt install waybar git cmake cava rofi
